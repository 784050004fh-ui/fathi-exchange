function sayHello() {
  alert("أهلاً بك! الموقع يشتغل من GitHub Pages ✅");
}